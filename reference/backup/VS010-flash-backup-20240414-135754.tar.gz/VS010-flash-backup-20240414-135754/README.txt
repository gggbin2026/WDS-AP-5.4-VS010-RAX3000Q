VS010 NAND 备份包  20240414-135754

★ 必看：
  manifest.txt         分区 / 偏移 / 大小 / sha256
  proc-mtd.txt         原始分区表
  mtd01-0_MIBIB.bin    ★ 分区表本体（r24 最需要）
  mtd13-0_ART.bin      ★ 每台唯一校准 + MAC（生成本机专属 BDF）
  mtd14-0_TRAINING.bin ★ NAND 训练数据（救砖必需）
  mtd08/09-0_CDT*.bin  ★ 板级配置（查 board-id 来源）
  mtd11/12-0_APPSBL*   U-Boot 本体

合计 0x00900000 = 9 MiB（不含 rootfs / UBI 卷）

上传：仓库 reference/backup/VS010-<日期>/
⚠ 若仓库公开：0:ART / 0:APPSBLENV 含 MAC，建议脱敏
⚠ 本包不含固件本体与任何配置密码

── manifest ──
# VS010 NAND 备份  20240414-135754
# 固件: Linux Nwrt 5.4.213 #0 SMP PREEMPT Sun Apr 14 05:49:22 2024 armv7l GNU/Linux
# 备份方式: 只读 dd /dev/mtdX
# 分区  mtd  偏移      大小      文件                          sha256
0:SBL1         mtd0   0x00000000 0x00080000 mtd00-0_SBL1.bin               4ad10cc055e02123684cac2e923be29caa66b7b25044226a816945e2a32f158c
0:MIBIB        mtd1   0x00080000 0x00080000 mtd01-0_MIBIB.bin              82f7685461086b6256068eb039add3aa56c37bfee78bae266c8c757f980090e2
0:BOOTCONFIG   mtd2   0x00100000 0x00040000 mtd02-0_BOOTCONFIG.bin         6a15bd292f617407cbc1487a8f3b2249621a0f11709d1cbba657f907a312ebf0
0:BOOTCONFIG1  mtd3   0x00140000 0x00040000 mtd03-0_BOOTCONFIG1.bin        6a15bd292f617407cbc1487a8f3b2249621a0f11709d1cbba657f907a312ebf0
0:QSEE         mtd4   0x00180000 0x00100000 mtd04-0_QSEE.bin               545dd957c8211095984b3461e728f12265a1f1284de1ca53d6b10f7b074ad005
0:QSEE_1       mtd5   0x00280000 0x00100000 mtd05-0_QSEE_1.bin             f5fb04aa5b882706b9309e885f19477261336ef76a150c3b4d3489dfac3953ec
0:DEVCFG       mtd6   0x00380000 0x00040000 mtd06-0_DEVCFG.bin             83aada9ce28f77f677f935634ceda361f23ef4909eff1f8fb9d8c82668291b26
0:DEVCFG_1     mtd7   0x003c0000 0x00040000 mtd07-0_DEVCFG_1.bin           3b874d3ba46c638fc3094f8e92fb744ca974893873f8885f54e23760f9b6311b
0:CDT          mtd8   0x00400000 0x00040000 mtd08-0_CDT.bin                8c57815044e7852a43e0b783b68957b9a41579607326124418b6e3f44238619a
0:CDT_1        mtd9   0x00440000 0x00040000 mtd09-0_CDT_1.bin              3b874d3ba46c638fc3094f8e92fb744ca974893873f8885f54e23760f9b6311b
0:APPSBLENV    mtd10  0x00480000 0x00080000 mtd10-0_APPSBLENV.bin          d599099bff06ae8ad4dba9e9f32ac363e3765062ab3baa6723837244eaa2a3ec
0:APPSBL       mtd11  0x00500000 0x00140000 mtd11-0_APPSBL.bin             6c689de54c66fb8e8fe6e2991c54ab708560c9e44a6226b57f3e03a7a6226bdd
0:APPSBL_1     mtd12  0x00640000 0x00140000 mtd12-0_APPSBL_1.bin           35805909a516a528e396b6ea22dab437b6f1c703afe92e92dddfa0243bfae738
0:ART          mtd13  0x00780000 0x00100000 mtd13-0_ART.bin                e97b8f7a5190171d19af5e5332c631ac6b9a9e4a1f64d2172ce1245aa7e79923
0:TRAINING     mtd14  0x00880000 0x00080000 mtd14-0_TRAINING.bin           f20caf33d751f34de1c9247b979602452c010737f37d95333cf75a1591ea9ba7
#
# 前 15 分区合计 0x00900000 = 9 MiB
# rootfs 起始 0x00900000（本机 size 0x06e00000 = 110 MiB，大分区 U-Boot）
# 🔴 未写入任何分区 / 未改 U-Boot / 未改配置 / 未重启
# 🔴 0:ART 含本机 MAC；公开仓库建议脱敏或私发
